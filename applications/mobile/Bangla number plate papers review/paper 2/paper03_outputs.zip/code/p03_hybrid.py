"""Paper #3 hybrid test: COCO vehicle detector -> Haar cascade (or our YOLO) for the plate inside each vehicle.

Four pipelines on the detection test photos (resized so the long side is 464 px, like the paper's 464x464 frames):
  yolo           our plate YOLO on the whole photo
  haar           OpenCV Haar plate cascade on the whole photo
  veh+haar       COCO YOLOv8n vehicles (conf >= 0.5) -> Haar inside each vehicle box  (the paper's design)
  veh+yolo       COCO YOLOv8n vehicles -> our plate YOLO inside each vehicle box
P / R / F1 at IoU >= 0.5 and frames per second on the GPU and on the CPU (4 threads, like a small PC).
  python p03_hybrid.py --plate runs/v8n_640/weights/best.pt --name hybrid --project runs
"""
import argparse
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common
cv2 = common.cv2_with_cascade()          # before anything else imports cv2 (OpenCV 5 has no Haar cascades)
import numpy as np
import torch
from det import gt_boxes, iou_matrix, split_files

VEHICLES = {2, 3, 5, 7}


def haar_boxes(casc, img, off=(0, 0)):
    g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    rects = casc.detectMultiScale(g, scaleFactor=1.05, minNeighbors=5, minSize=(24, 10))
    return [(x + off[0], y + off[1], x + w + off[0], y + h + off[1]) for x, y, w, h in rects]


def yolo_boxes(model, img, dev, off=(0, 0), imgsz=464, conf=0.25):
    r = model.predict(img, imgsz=imgsz, conf=conf, device=dev, verbose=False)[0]
    return [(b[0] + off[0], b[1] + off[1], b[2] + off[0], b[3] + off[1]) for b in r.boxes.xyxy.cpu().numpy()]


def vehicles(veh, img, dev):
    r = veh.predict(img, imgsz=464, conf=0.5, device=dev, verbose=False)[0]
    return [b.astype(int) for b, c in zip(r.boxes.xyxy.cpu().numpy(), r.boxes.cls.cpu().numpy()) if int(c) in VEHICLES]


def pipeline(name, img, plate, veh, casc, dev):
    if name == 'yolo':
        return yolo_boxes(plate, img, dev)
    if name == 'haar':
        return haar_boxes(casc, img)
    out = []
    for x1, y1, x2, y2 in vehicles(veh, img, dev):
        roi = img[max(0, y1):y2, max(0, x1):x2]
        if roi.size == 0:
            continue
        out += haar_boxes(casc, roi, (x1, y1)) if name == 'veh+haar' else yolo_boxes(plate, roi, dev, (x1, y1))
    return out


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--plate', required=True)
    p.add_argument('--data', required=True)
    p.add_argument('--name', default='hybrid')
    p.add_argument('--project', required=True)
    p.add_argument('--max', type=int, default=None)
    a = p.parse_args()
    from ultralytics import YOLO
    run = Path(a.project) / a.name
    run.mkdir(parents=True, exist_ok=True)
    casc = cv2.CascadeClassifier(os.path.join(cv2.data.haarcascades, 'haarcascade_russian_plate_number.xml'))
    imgs, lab = split_files(a.data, 'test')
    imgs = imgs[:a.max]
    res = {'run': a.name, 'kind': 'hybrid', 'cascade': 'OpenCV haarcascade_russian_plate_number.xml (paper\'s Bangla '
           'cascade is not public)', 'images': len(imgs), 'pipelines': {}}
    for dev in (['0'] if torch.cuda.is_available() else []) + ['cpu']:
        if dev == 'cpu':
            torch.set_num_threads(4)
            cv2.setNumThreads(4)
        plate, veh = YOLO(a.plate), YOLO('yolov8n.pt')
        for name in ('yolo', 'haar', 'veh+haar', 'veh+yolo'):
            tp = fp = fn = 0
            ms = []
            sub = imgs if dev != 'cpu' else imgs[:120]
            for i, path in enumerate(sub):
                img = cv2.imread(str(path))
                s = 464 / max(img.shape[:2])
                img = cv2.resize(img, None, fx=s, fy=s)
                h, w = img.shape[:2]
                g, _ = gt_boxes(lab(Path(path)), w, h)
                t0 = time.perf_counter()
                pb = pipeline(name, img, plate, veh, casc, dev)
                if dev != 'cpu':
                    torch.cuda.synchronize()
                if i >= 5:
                    ms.append(1000 * (time.perf_counter() - t0))
                m = iou_matrix(np.array(pb).reshape(-1, 4), g)
                used = set()
                for k in range(m.shape[0]):
                    j = int(np.argmax(m[k])) if m.shape[1] else -1
                    if j >= 0 and m[k, j] >= 0.5 and j not in used:
                        used.add(j)
                tp += len(used); fp += len(pb) - len(used); fn += len(g) - len(used)
            P, R = tp / max(1, tp + fp), tp / max(1, tp + fn)
            d = res['pipelines'].setdefault(name, {})
            if dev != 'cpu':
                d.update({'P_%': round(100 * P, 2), 'R_%': round(100 * R, 2),
                          'F1_%': round(200 * P * R / max(1e-9, P + R), 2)})
                d['gpu_fps'] = round(1000 / np.mean(ms), 1) if ms else None
            else:
                d['cpu_fps'] = round(1000 / np.mean(ms), 1) if ms else None
                d.setdefault('P_%', round(100 * P, 2)); d.setdefault('R_%', round(100 * R, 2))
            print(dev, name, d, flush=True)
    res['gpu'] = torch.cuda.get_device_name(0) if torch.cuda.is_available() else None
    res['cpu'] = 'Kaggle CPU, 4 threads'
    common.save_json(res, run / 'results.json')


if __name__ == '__main__':
    main()
