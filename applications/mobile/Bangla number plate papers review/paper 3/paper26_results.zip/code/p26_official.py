"""Paper #26: get the OFFICIAL YOLOv12 code (sunsmarterjie/yolov12, its own Ultralytics 8.3.63 fork) next to our
Ultralytics 8.4.170, so both can train the same split in the same notebook.

  python p26_official.py --dir /kaggle/working/yolov12_official
  then run det.py with  PYTHONPATH=/kaggle/working/yolov12_official:<lprkit>  and  --model <dir>/yolov12s.pt

- clones the repo at a pinned commit (the code the results below come from)
- NumPy 2 fix: np.trapz was removed, the fork's metrics.py still calls it -> np.trapezoid when needed
- downloads the authors' COCO weights (release "turbo": yolov12n/s.pt, the v1.0 turbo models of the README)
- FlashAttention: the fork only uses it on Ampere+ GPUs; on the T4 it falls back to plain attention (same maths)
- prints the version the fork reports, so the log shows which Ultralytics actually ran
"""
import argparse
import os
import subprocess
import sys
import urllib.request

REPO = 'https://github.com/sunsmarterjie/yolov12'
COMMIT = '2abab7153a065fb2925e8088e9ca2b19016ab7d6'      # HEAD on 12 Oct 2026
WEIGHTS = 'https://github.com/sunsmarterjie/yolov12/releases/download/turbo/{}.pt'


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--dir', required=True)
    p.add_argument('--weights', nargs='+', default=['yolov12n', 'yolov12s'])
    a = p.parse_args()
    if not os.path.exists(os.path.join(a.dir, '.git')):
        subprocess.check_call(['git', 'clone', '-q', REPO, a.dir])
    subprocess.check_call(['git', '-C', a.dir, 'checkout', '-q', COMMIT])
    m = os.path.join(a.dir, 'ultralytics', 'utils', 'metrics.py')
    s = open(m, encoding='utf-8').read()
    if 'np.trapz(' in s:
        s = s.replace('np.trapz(', '(np.trapezoid if hasattr(np, "trapezoid") else np.trapz)(')
        open(m, 'w', encoding='utf-8').write(s)
    for w in a.weights:
        f = os.path.join(a.dir, f'{w}.pt')
        if not os.path.exists(f):
            urllib.request.urlretrieve(WEIGHTS.format(w), f)
        print('weights', f, os.path.getsize(f) // 1024, 'KB')
    env = dict(os.environ, PYTHONPATH=a.dir)
    out = subprocess.run([sys.executable, '-c', 'import ultralytics, sys; print(ultralytics.__version__, ultralytics.__file__)'],
                         env=env, capture_output=True, text=True)
    print('official fork imports as:', out.stdout.strip() or out.stderr[-800:])
    norm = lambda s: os.path.normcase(os.path.normpath(s)).replace('\\', '/')
    if norm(os.path.abspath(a.dir)) not in norm(out.stdout):
        sys.exit('the fork did not load first; check PYTHONPATH')


if __name__ == '__main__':
    main()
